Splunk Global Monitoring Console (GMC) version 1.0.0
Copyright (C) 2005-2020 Splunk Inc. All Rights Reserved.

For documentation, see: https://github.com/amir-khamis/gmc
